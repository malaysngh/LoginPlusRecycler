package com.example.loginplusrecycler
data class UsersItem(
    val avatar_url: String,
    val login: String,
)
